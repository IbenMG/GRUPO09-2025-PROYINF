from django.apps import AppConfig


class BuscadorFuentesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'buscador_fuentes'
